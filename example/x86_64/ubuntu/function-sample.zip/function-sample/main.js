var request = require('request');
var server = process.env.SERVER;
var token = process.env.TOKEN;
var uuid = process.env.UUID;
var output = '';

function sendOutput(what) {

  const body = JSON.stringify({
    token,
    output: what,
    uuid
  });

  const options = {
    url: server + '/function',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': body.length
    },
    body
  };

  request(options, (error, response) => {
    if (error) {
      console.log('An error has occurred.' + error);
    }
  });
}

sendOutput('Hello, World!');
